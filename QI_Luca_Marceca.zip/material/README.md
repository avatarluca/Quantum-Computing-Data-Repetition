# Optimal Number of Data Repetitions in Quantum Ansatz and Data Encoding

# Source
https://iopscience.iop.org/article/10.1209/0295-5075/134/10002
https://www.frontiersin.org/journals/physics/articles/10.3389/fphy.2020.00297/full
https://journals.aps.org/pra/abstract/10.1103/PhysRevA.103.032430